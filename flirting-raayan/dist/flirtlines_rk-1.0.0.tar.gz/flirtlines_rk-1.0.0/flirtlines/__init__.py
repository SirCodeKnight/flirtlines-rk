from .lines import get_flirty_line
