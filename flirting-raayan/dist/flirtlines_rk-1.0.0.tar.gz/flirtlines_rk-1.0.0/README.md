# FlirtLines 😘
A simple Python package that gives you random flirty lines.  

## Installation  
```sh
pip install flirtlines
